// Este archivo se encarga de una sola cosa: conectar la aplicación a MongoDB.
// Lo separamos del resto para que, si el día de mañana cambia la forma de
// conectarse (otra URI, otra configuración), solo se toque este archivo.
const mongoose = require('mongoose');

async function conectarDB() {
  try {
    // La URI de conexión viene del archivo .env (nunca se escribe directo aquí,
    // para no subir contraseñas de la base de datos a GitHub por accidente).
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Conectado a MongoDB (CityHunterDB)');
  } catch (error) {
    console.error('Error al conectar a MongoDB:', error.message);
    process.exit(1);
  }
}

module.exports = conectarDB;
